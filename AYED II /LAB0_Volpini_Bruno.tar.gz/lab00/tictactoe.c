#include <stdlib.h>  /* exit() y EXIT_FAILURE */
#include <stdio.h>   /* printf(), scanf()     */
#include <stdbool.h> /* Tipo bool             */

#include <assert.h>  /* assert() */

#define CELL_MAX (5 * 5- 1)

#define MAX 5

void print_sep(int length) {
    printf("\t ");
    for (int i=0; i < length;i++) printf("................");
    printf("\n");

}

void print_board(char board[MAX][MAX])
{
    int cell = 0;

    print_sep(MAX);
    for (int row = 0; row < MAX; ++row) {
        for (int column = 0; column < MAX; ++column) {
            printf("\t | %d: %c ", cell, board[row][column]);
            ++cell;
        }
        printf("\t | \n");
        print_sep(MAX);
    }
}

char get_winner(char board[MAX][MAX])
{
    char winner = '-';
    for(unsigned int j = 0; j<MAX; j++)
        {
            bool check_X = true;
            bool check_O = true;
            for(unsigned int i = 0; i<MAX; i++)
             {
                check_X = check_X && (board[j][i] == 'X');
                check_O = check_O && (board[j][i] == 'O');
            }
            if (check_X == true){
            winner = 'X';
            return winner;
            }
            if (check_O == true){
                winner = 'O';
                return winner;
            }
        }
    for(unsigned int j = 0; j<MAX; j++)
        {
            bool check_X = true;
            bool check_O = true;
            for(unsigned int i = 0; i<MAX; i++)
             {
                check_X = check_X && (board[i][j] == 'X');
                check_O = check_O && (board[i][j] == 'O');
            }
            if (check_X == true){
            winner = 'X';
            return winner;
            }
            if (check_O == true){
                winner = 'O';
                return winner;
            }
        }
        bool check_X = true;
        bool check_O = true;
    for(unsigned int d = 0; d<MAX; d++)
        {

            check_X = check_X && (board[d][d] == 'X');
            check_O = check_O && (board[d][d] == 'O');            

        }
        
        if (check_X == true){
        winner = 'X';
        return winner;
         }
        if (check_O == true){
        winner = 'O';
        return winner;
        }
     for(int j = MAX-1; j>=0; j--)
        {
            bool check_X = true;
            bool check_O = true;
            for(unsigned int i = 0; i<MAX; i++)
             {
                check_X = check_X && (board[i][i] == 'X');
                check_O = check_O && (board[i][j] == 'O');
            }

        }
       if (check_X == true){
         winner = 'X';
            return winner;
            }
            if (check_O == true){
                winner = 'O';
                return winner;
            }

    return winner;
}


bool has_free_cell(char board[MAX][MAX])
{
    bool free_cell=false;
    for (unsigned int i = 0; i< MAX; i++ )
        {
            for (unsigned int j = 0; j < MAX; j++ )
            {if (board[i][j]== '-'){free_cell = true;}}

        }
    

    return free_cell;
}

int main(void)
{
    printf("TicTacToe COMPLETO:'(]\n");

    char board[MAX][MAX] = {
        { '-', '-', '-', '-', '-' },
        { '-', '-', '-', '-', '-' },
        { '-', '-', '-', '-', '-' },
        { '-', '-', '-', '-', '-' },
        { '-', '-', '-', '-', '-' }
    };

    char turn = 'X';
    char winner = '-';
    int cell = 0;
    while (winner == '-' && has_free_cell(board)) {
        print_board(board);
        printf("\nTurno %c - Elija posición (número del 0 al %d): ", turn,
               CELL_MAX);
        int scanf_result = scanf("%d", &cell);
        if (scanf_result <= 0) {
            printf("Error al leer un número desde teclado\n");
            exit(EXIT_FAILURE);
        }
        if (cell >= 0 && cell <= CELL_MAX) {
            int row = cell / MAX;
            int colum = cell % MAX;
            if (board[row][colum] == '-') {
                board[row][colum] = turn;
                turn = turn == 'X' ? 'O' : 'X';
                winner = get_winner(board);
            } else {
                printf("\nCelda ocupada!\n");
            }
        } else {
            printf("\nCelda inválida!\n");
        }
    }
    print_board(board);
    if (winner == '-') {
        printf("Empate!\n");
    } else {
        printf("Ganó %c\n", winner);
    }
    return 0;
}
