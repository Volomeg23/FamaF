#ifndef MY_BOOL_H
#define MY_BOOL_H
#define true 1
#define false 0

typedef int boolean;

#endif

