#ifndef _PIVOT_H_
#define _PIVOT_H_

#include <stdbool.h>

bool is_pivot(int array[], unsigned int length, unsigned int piv);

#endif
