#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <stdbool.h>

int pedirEntero (void) {
    int n = 0;
    printf("Ingrese un valor para el indice\n");
    scanf("%d", &n);
    return n;
}


void pedirArreglo (int a[], int n_max){
    assert(n_max >= 0);
    int i = 0;
    while (i < n_max) {
        a[i] = pedirEntero();
        i++;
    }
}

void imprimeArreglo (int a[], int n_max) {
    assert(n_max >= 0);
    int i = 0;
    printf("[");
    while (i < n_max) {
        printf("%d,", a[i]);
        i++;
    }
    printf("]\n");
}

bool todos_positivos(int a[], int tam){
int i;
bool e;
e = true;
i = 0;

while (i<tam - 1) {
    e = e && (a[i] > 0);
    i++ ;
}
if (e) {
    printf("Todos positivos\n");
} else {
    printf("No son todos positivos\n");
}
return e; 


#define N 6
int main (void) {
    int a[N];
    pedirArreglo(a,N);
    imprimeArreglo(a,N);
    todos_positivos(a,N);
    return 0;
}


