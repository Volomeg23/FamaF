#include <stdlib.h>
#include <stdio.h>
#include <assert.h>

// c)

void imprimeHola (void) {
    printf("Hola Hola\n");
}

void imprimeChau (void) {
    printf("Chau Chau\n");
}



int main (void) {
    imprimeHola(); 
    imprimeChau();
    return 0;
}